#arquivo de entrada por embryo
#SRR490973_20	chr4	83288425	.	T	.	.	PASS	ADP=121;WT=1;HET=0;HOM=0;NC=0	GT:GQ:SDP:DP:RD:AD:FREQ:PVAL:RBQ:ABQ:RDF:RDR:ADF:ADR	0/0:70:121:121:38:0:0%:1E0:37:0:14:24:0:0	chr4	rs10003180	chr4	HNRNPD	protein_coding	83273651	83295656	NONE	NONE	0/0	70	121	121	38	00%	1	37	0	14	24	0	0	38	1	0	TH	1

args=commandArgs(TRUE)

if(as.character(args[2])=="5"){
        files=list.files(path=args[1],full.names=TRUE)
	print(files)
}

if(as.character(args[2])=="8"){
        files=list.files(path=args[1],full.names=TRUE,pattern="noINC")
	print(files)
}



for(i in files){
	Sample<-read.table(i,header=FALSE)
	
	duplicated=Sample[duplicated(sub(x=as.character(Sample[,14]),pattern='rs',replacement='')),14]
	only_dup=Sample[Sample[,14] %in% duplicated,]

	if(as.character(args[2])=="5"){
	        filename=gsub(i,pattern="04_catCells", replacement="05_commom_SNPs")
	}
	
	if(as.character(args[2])=="8"){
	        filename=gsub(i,pattern="07_GenesInconsistentes", replacement="08_commomSNPs_noINC")
	}

	write.table(only_dup[order(only_dup[,14]),],file=filename, sep="\t", quote=FALSE,col.names=FALSE,row.names=FALSE)
}




