args=commandArgs(TRUE)

#listaBIAL=list.files(pattern="_TH_Sumfreq20_no_male_X-bial_commom_SNPs_noCell_Inc.txt")
#listaTOTAL=list.files(patter="_TH_noPS_noOV_ajust_Sumfreq20_no_male_X_BIAL_noIncCell.txt")

listaBIAL=list.files(pattern="_BIAL_genes.txt",full.names=TRUE,path=args[1])
listaTOTAL=list.files(patter="_all_genes.txt",full.names=TRUE,path=args[1])

#counting total genes
#vai até s<23
s=1
while (s<23){
results=cbind("Cell","Ratio")
chr=paste("chr",s,sep="")

for (i in listaBIAL) {
	blah=gsub(gsub(i,pattern="_BIAL_genes.txt", replacement=""),pattern=".*/",replacement="")
   for (k in listaTOTAL) {
		bleh=gsub(gsub(k,pattern="_all_genes.txt", replacement=""),pattern=".*/",replacement="")

       
		if(blah == bleh){
		        tempBIAL<-read.table(i, header=FALSE)
			tempTOTAL<-read.table(k, header=FALSE)
			print(i)
			print(k)

			tempBIALchr=tempBIAL[tempBIAL[,2]==chr,]
			tempTOTALchr=tempTOTAL[tempTOTAL[,2]==chr,]

			BIAL=tempBIALchr[tempBIALchr[,8]<0.8,]
			countBIAL=length(unique(BIAL[,3]))

			countTOTAL=length(unique(tempTOTALchr[,3]))
			ratio=countBIAL/countTOTAL

			Cell=tempBIAL[1,1]

			caca = cbind(as.character(Cell),as.numeric(ratio))

			results=rbind(results,caca)

			}

		}


}
write.table(results,file=paste(args[2],"/",chr,"_","BIAL_ratio.txt",sep=""),quote=FALSE,col.names=FALSE,row.names=FALSE, sep="\t")
print(chr)
s=s+1
}


#### repeat for X chromossome

chr="chrX"
results=cbind("Cell","Ratio")

print("chrX")
for (i in listaBIAL) {
	blah=gsub(gsub(i,pattern="_BIAL_genes.txt", replacement=""),pattern=".*/",replacement="")
   for (k in listaTOTAL) {
                bleh=gsub(gsub(k,pattern="_all_genes.txt", replacement=""),pattern=".*/",replacement="")


                if(blah == bleh){
                        tempBIAL<-read.table(i, header=FALSE)
                        tempTOTAL<-read.table(k, header=FALSE)
                        print(i)
                        print(k)

                        tempBIALchr=tempBIAL[tempBIAL[,2]==chr,]
                        tempTOTALchr=tempTOTAL[tempTOTAL[,2]==chr,]

                        BIAL=tempBIALchr[tempBIALchr[,8]<0.8,]
                        countBIAL=length(unique(BIAL[,3]))

                        countTOTAL=length(unique(tempTOTALchr[,3]))
                        ratio=countBIAL/countTOTAL

                        Cell=tempBIAL[1,1]

                        caca = cbind(as.character(Cell),as.numeric(ratio))

                        results=rbind(results,caca)

                        }

                }


}
write.table(results,file=paste(args[2],"/",chr,"_","BIAL_ratio.txt",sep=""),quote=FALSE,col.names=FALSE,row.names=FALSE, sep="\t")



