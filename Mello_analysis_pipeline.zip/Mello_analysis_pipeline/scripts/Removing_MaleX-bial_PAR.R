### use: Rscript [Male_Control_file] [PAR_file]  [PATH variable]

##Removing X-linked bialleic SNPs found in the male control
##Removing SNPs at the pseudo autosomic region
args=commandArgs(TRUE)

Male_XBIAL<-read.table(args[1], header=FALSE)
PAR<-read.table(args[2], header=FALSE)

snp=union(PAR[,4],Male_XBIAL[,4])  ## identify snps present in PAR or biallelic Male control

files=list.files(path=args[3],full.names=TRUE)
files=files[grep(files,pattern="Embryo_list.txt",invert=TRUE)]

print(files)

for (i in files){
	Sample<-read.table(i, header = FALSE)
	print(i)

	data=setdiff(Sample[,14],snp)
	merged=merge(x=Sample, y=data, by.x=14, by.y=1)[,c(2:14,1,15:40)]


	filename=gsub(i,pattern="01_renamed",replacement="02_03_remove_Male_BIAL_PAR")
	print(filename)
	write.table(merged,file=filename,quote=FALSE,col.names=FALSE,row.names=FALSE, sep="\t")
}


