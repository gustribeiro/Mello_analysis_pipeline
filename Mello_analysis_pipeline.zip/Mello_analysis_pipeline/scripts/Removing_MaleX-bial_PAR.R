### use: Rscript [Male_Control_file] [PAR_file]  [PATH variable]

#Removing X-linked bialleic SNPs found in the male control

args=commandArgs(TRUE)

Male_XBIAL<-read.table(args[1], header=FALSE)
PAR<-read.table(args[2], header=FALSE)

snp=union(PAR[,4],Male_XBIAL[,4])  ## identify snps present in PAR or biallelic Male control

files=list.files(path=args[3],full.names=TRUE)
files=files[grep(files,pattern="Embryo_list.txt",invert=TRUE)]

print(files)

for (i in files){
	Sample<-read.table(i, header = FALSE)
	print(i)

	caca=setdiff(Sample[,14],snp)
	merged=merge(x=Sample, y=caca, by.x=14, by.y=1)[,c(2:14,1,15:40)]


	filename=gsub(i,pattern="01_renamed",replacement="02_03_remove_hES_BIAL_PAR")
	print(filename)
	write.table(merged,file=filename,quote=FALSE,col.names=FALSE,row.names=FALSE, sep="\t")
}


##Removing SNPs at the pseudo autosomic region
#PAR<-read.table("/data2/jmello/scripts/ADEvsBIAL_MegaPipe/PAR/chrX_PAR1e2", header=FALSE)
#files=list.files(pattern="_DP20_noMaleXBIAL")

#for (i in files){
#	Sample<-read.table(i, header = FALSE)
#	print(i)
	
#	caca=setdiff(merged[,14],PAR[,3])
#	merged=merge(x=merged, y=caca, by.x=14, by.y=1)[,c(2:14,1,15:40)]
	
#	filename=gsub(i,pattern="_DP20_noMaleXBIAL",replacement="_DP20_noMaleXBIAL_noPAR")
#	print(filename)
#	write.table(merged,file=filename,quote=FALSE,col.names=FALSE,row.names=FALSE, sep="\t")
#}


