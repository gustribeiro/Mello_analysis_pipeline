#!/usr/bin/perl
# sel_var_w_diff_freq.pl
# Created by Maria Vibranovski
# Oct 23th  2014

#Read the file's entries

for($i=0;$i<=$#ARGV;$i+=2){
   
    if($ARGV[$i] eq "-v"){
        $varfile = $ARGV[$i+1];
    }
    if($ARGV[$i] eq "-o"){
        $outfile = $ARGV[$i+1];
    }
}

#Verify if the entries were given, otherwise, explain the order of entries

if(($varfile eq "") || ($outfile eq "")){
    print "Usage: perl sel_var_w_diff_fre.pl -v -o\n";
    print "\t-v: variants  file.\n";
    print "\t-o: out  file.\n";
    exit(0);
}


#open and write on log file
open (LOG, ">>sel_var_w_diff_freq_0or1.log") ;
print LOG "beggin \n".(localtime)."\n";
print LOG "Var file $varfile\n" ;
print LOG "Out file $outfile\n" ;

#open OUT file
open (OUT, ">$outfile");


#open and read mRNA file

#V1      V2      V3      V4      V5      V6      V7      V8      V9      V10     V11     V12     V13     V14     V15     V16     V17     V18     V19     V20     V21     V22     V23     V24     V25     V26     V27     V28     V29
#SRR490961       chr5    180276788       PASS    GT:GQ:SDP:DP:RD:AD:FREQ:PVAL:RBQ:ABQ:RDF:RDR:ADF:ADR    0/0     37      19      19      19      0       0%      1       37      0       11      8       0       0       ZFP62   rs1000015       protein_coding  NONE    NONE    1       0       19      Hg19    1
#SRR490962       chr5    180276788       PASS    GT:GQ:SDP:DP:RD:AD:FREQ:PVAL:RBQ:ABQ:RDF:RDR:ADF:ADR    0/0     47      26      26      26      0       0%      1       38      0       11      15      0       0       ZFP62   rs1000015       protein_coding  NONE    NONE    1       0       26      Hg19    1
#SRR490964       chr5    180276788       PASS    GT:GQ:SDP:DP:RD:AD:FREQ:PVAL:RBQ:ABQ:RDF:RDR:ADF:ADR    0/0     29      15      15      15      0       0%      1       38      0       9       6       0       0       ZFP62   rs1000015       protein_coding  NONE    NONE    1       0       15      Hg19    1
undef @data;
open(VAR, "<$varfile");
$rs="";
$count=0;
$count_diff++;
$k=0;
while(<VAR>){
    $line=$_;
    chomp($line);
    undef @data;
    @data=split(/\t/, $line);

    if($data[13] ne $rs){
	
	if($rs ne ""){
	    $count++;
	    if($count=~/00000/){
		#print "$count\n";
	    }
	    $diff=0;
	    for($i=0; $i<=$#datasub; $i++){
		for($j=0; $j<=$#datasub; $j++){
		    if(($datasub[$i][1] != $datasub[$j][1]) && ($datasub[$i][1] !=0.5) && ($datasub[$j][1] != 0.5)){
			$diff=1;
		    }
		}
	    }
	    if($diff==1){
		$count_diff++;
		for($i=0; $i<=$#datasub; $i++){
		    print OUT "$datasub[$i][0]\n";
		}
	    }
	}
	$rs=$data[13];
	undef @datasub;
    	$k=0;
	
    }
    $datasub[$k][0]=$line;
    if($data[36]>=0.8){
	$datasub[$k][1]=1;
    }elsif($data[36]>0.2){
	$datasub[$k][1]=0.5;
    }else{
	$datasub[$k][1]=0;
    }
    $k++;
}
close(VAR);
if($diff==1){
    $count_diff++;
    for($i=1; $i<=$#datasub; $i++){
	print OUT "$datasub[$i][0]\n";
    }
}

close(OUT);
print LOG "Count cases $count_diff\n";
print LOG "end \n".(localtime)."\n";
close(LOG);

