#!/usr/bin/perl
# Automatic_inconsistent_filter.pl
# Created by Maria Vibranovski
# June 18th 2016

#Read the file's entries

for($i=0;$i<=$#ARGV;$i+=2){
   
    if($ARGV[$i] eq "-v"){
        $varfile = $ARGV[$i+1];
    }
    if($ARGV[$i] eq "-o"){
        $outfile = $ARGV[$i+1];
    }
    if($ARGV[$i] eq "-a"){
        $allfile = $ARGV[$i+1];
    }
    if($ARGV[$i] eq "-f"){
        $forbfile = $ARGV[$i+1];
    }
    if($ARGV[$i] eq "-d"){
        $diffile = $ARGV[$i+1];
    }
}

#Verify if the entries were given, otherwise, explain the order of entries

if(($varfile eq "") || ($allfile eq "") || ($outfile eq "") || ($forbfile eq "") || ($diffile eq "")){
    print "Usage: Automatic_inconsistent_filter.pl -v -o -a -f -d\n";
    print "\t-v: vardiff  file.\n";
    print "\t-d: diff 0or1  file.\n";
    print "\t-o: out  file.\n";
    print "\t-a: all  file.\n";
    print "\t-f: forbiden  file.\n";
    exit(0);
}


#open and write on log file
open (LOG, ">>Automatic_inconsistent_filter.log") ;
print LOG "beggin \n".(localtime)."\n";
print LOG "Var diff file $varfile\n" ;
print LOG "Diff 0or1 file $varfile\n" ;
print LOG "All file $allfile\n" ;
print LOG "Out file $outfile\n" ;
print LOG "Forbiden file $forbfile\n" ;

#open OUT file
open (OUT, ">$outfile");


#open and read vardiff file
#ERR1042179      chr6    7310259 rs10004 chr6    SSR1    protein_coding  7268539 7347679 NONE    NONE    chr6    7310259 .       A .       .       PASS    ADP=13;WT=1;HET=0;HOM=0;NC=0    GT:GQ:SDP:DP:RD:AD:FREQ:PVAL:RBQ:ABQ:RDF:RDR:ADF:ADR    0/0:4:13:13:8:5:38.46%:1.9565E-2:35:31:5:3:2:3  0/0     4       13      13      8       5       38.46%  0.019565        35      31      5       3       2       3       13      0.615385        0.384615        TH      0.615385

#SRR490985	chr7	6013153	PASS	GT:GQ:SDP:DP:RD:AD:FREQ:PVAL:RBQ:ABQ:RDF:RDR:ADF:ADR	0/0	145	78	78	78	0	0%	1	36	0	46	32	0	0	PMS2	rs10000	protein_coding	NONE	NONE	78	1	0	TH	1


undef %hash_var;
open(VAR, "<$varfile");
while(<VAR>){
    $line=$_;
    chomp($line);
    undef @data;
    @data=split(/\t/, $line);
    undef $class;

    if($data[39]>=0.8){ #39 = FreqAdjust
	$class="ade";
    }else{
	$class="bia"
    }

    if($hash_gene{$data[15]}{$data[0]} eq ""){ # 15 = Gene
	$hash_gene{$data[15]}{$data[0]}=$class;
    }
    else{
	if($class ne $hash_gene{$data[15]}{$data[0]}){
	    $hash_var{$data[15]}{$data[0]}{$data[13]}=1; #13 = SNP
	}
    }
}
close(VAR);

undef %hash_forbi;
open(DIF, "<$diffile");
while(<DIF>){
    $line=$_;
    chomp($line);
    undef @data;
    @data=split(/\t/, $line);
    if($hash_var{$data[15]}{$data[0]}{$data[13]}==1){
	$hash_forbi{$data[15]}{$data[0]}=1;
    }

}
close(DIF);

#ERR1042173      chr1    787347  rs376129631     chr1    RP11-206L10.11  processed_transcript    762988  794826  NONE    NONE    chr1    787347  .       A       .       .       PASS    ADP=8;WT=1;HET=0;HOM=0;NC=0     GT:GQ:SDP:DP:RD:AD:FREQ:PVAL:RBQ:ABQ:RDF:RDR:ADF:ADR    0/0:14:8:8:8:0:0%:1E0:38:0:3:5:0:0      0/0     14      8       8       8       0       0%      1E0     38      0       3       5       0       0       8       1       0       TH      1

#SRR490985	chr7	6013153	PASS	GT:GQ:SDP:DP:RD:AD:FREQ:PVAL:RBQ:ABQ:RDF:RDR:ADF:ADR	0/0	145	78	78	78	0	0%	1	36	0	46	32	0	0	PMS2	rs10000	protein_coding	NONE	NONE	78	1	0	TH	1

undef @data;
$count=0;
open(ALL, "<$allfile");
open(FOR, ">$forbfile");
while(<ALL>){
    $line=$_;
    chomp($line);
    undef @data;
    $count++;
    if($count=~/00000/){
	print "$count\n";
    }
    @data=split(/\t/, $line);
    if($hash_forbi{$data[15]}{$data[0]}!=1){
	print OUT "$line\n";
    }
    else{
	print FOR "$line\n";
    }
       
}
close(ALL);
close(FOR);
close(OUT);
print LOG "end \n".(localtime)."\n";
close(LOG);

