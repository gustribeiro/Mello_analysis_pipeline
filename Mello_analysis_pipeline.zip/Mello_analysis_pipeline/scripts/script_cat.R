#### concatenates all cells of the same embryo
#### use: Rscript [Embryo_list file] [path_input] [path_output]


args=commandArgs(TRUE)

cell_list=read.table(args[1],header=TRUE)
files=list.files(args[2],full.names=TRUE)

for(i in unique(cell_list[,1])){
	embryo=lapply(cell_list[cell_list[,1]==i,2],function(x) read.table(files[grep(files,pattern=x)]))
	embryo=do.call(rbind,embryo)
	filename=paste(args[3],"/",i,".txt",sep="")
	write.table(embryo,file=filename,quote=FALSE,sep="\t",row.names=FALSE,col.names=FALSE)
}
