
lista=list.files(pattern="ADE_BIAL")


    pdf(file="teste.pdf")

#tiff("chrABIAL_lowres.tiff", width = 45, height = 30, units = 'cm', res = 300)
par(mfrow=c(3,3))
#m <- matrix(c(1,2,3,4,5,6,7,8,9,10,11,12,13,14), nrow = 4, ncol = 6)
#layout(m)
for (i in lista){
ALLSamples<-read.table(i, header=TRUE)
print(i)

title=gsub(i, pattern="_ADE_BIAL", replace="")
#title=gsub(title, pattern="_BIAL_ratio", replace="")

#coss test
ADE =cor.test(ALLSamples$ADE , ALLSamples $POS) # ADE 
BIAL=cor.test(ALLSamples$BIAL , ALLSamples$POS) #BIAL


par(mar=c(2,3,1.2,1))
# bottom, left, top and right margins

# Bial / Tota
plot(ALLSamples $POS, ALLSamples $BIAL, lwd=2, xlab="",font.lab = 1, cex.axis = 1, cex.lab=1, cex.main=1.5, ylim=c(0,0.25), xaxt="n", ylab="") 
abline(lm(ALLSamples $BIAL ~ ALLSamples $POS), lwd=2)
text(5.3,0.24, cex = 0.8,font = 2, paste("corr =",round(BIAL $estimate, 4),"\n p =",round(BIAL $p.value,4)))

#ADE/Total
lines(ALLSamples $POS, ALLSamples $ADE, lwd=2, type="p", col=2)
abline(lm(ALLSamples $ADE ~ ALLSamples $POS), col="red", lwd=2)
text(5.3,0.2, cex = 0.8,font = 2,col=2, paste("corr =",round(ADE $estimate, 4),"\n p =",round(BIAL $p.value,4)))


axis(1,at=2:6,labels=c("4cell", "8cell","Mor.","Blas.","hESp0"),font.axis=1, cex.axis=1, las = 1)
text(4,0.25, title, cex=1, font=2)


}

dev.off()


