##listaADE=list.files(pattern="_Diff_0or1_noCell_Inc.txt")
##listaTOTAL=list.files(pattern="_TH_noPS_noOV_ajust_Sumfreq20_no_male_X_BIAL_noIncCell.txt")

args=commandArgs(TRUE)

listaADE=list.files(pattern="_ADE_genes.txt",full.names=TRUE,path=args[1])
listaTOTAL=list.files(patter="_all_genes.txt",full.names=TRUE,path=args[1])

#counting total genes
#vai ateh s<23
s=1
while (s<23){
results=cbind("Cell","Ratio")
chr=paste("chr",s,sep="")

for (i in listaADE){
        blah=gsub(gsub(i,pattern="_ADE_genes.txt", replacement=""),pattern=".*/",replacement="")
   for (k in listaTOTAL){
                bleh=gsub(gsub(k,pattern="_all_genes.txt", replacement=""),pattern=".*/",replacement="")
       
		if(blah == bleh){
		        tempADE<-read.table(i, header=FALSE)
			tempTOTAL<-read.table(k, header=FALSE)
			print(i)
			print(k)

			tempADEchr=tempADE[tempADE[,2]==chr,]
			tempTOTALchr=tempTOTAL[tempTOTAL[,2]==chr,]

			ADE=tempADEchr[tempADEchr[,8]>=0.8,]
			countADE=length(unique(ADE[,3]))

			countTOTAL=length(unique(tempTOTALchr[,3]))
			ratio=countADE/countTOTAL

			Cell=tempADE[1,1]

			caca = cbind(as.character(Cell),as.numeric(ratio))

			results=rbind(results,caca)

			}

		}


}
write.table(results,file=paste(args[2],"/",chr,"_","ADE_ratio.txt",sep=""),quote=FALSE,col.names=FALSE,row.names=FALSE, sep="\t")
print(chr)
s=s+1
}

#### repeat for X chromossome

chr="chrX"
results=cbind("Cell","Ratio")
print(chr)

for (i in listaADE){
        blah=gsub(gsub(i,pattern="_ADE_genes.txt", replacement=""),pattern=".*/",replacement="")
   for (k in listaTOTAL){
                bleh=gsub(gsub(k,pattern="_all_genes.txt", replacement=""),pattern=".*/",replacement="")

                if(blah == bleh){
                        tempADE<-read.table(i, header=FALSE)
                        tempTOTAL<-read.table(k, header=FALSE)
                        print(i)
                        print(k)

                        tempADEchr=tempADE[tempADE[,2]==chr,]
                        tempTOTALchr=tempTOTAL[tempTOTAL[,2]==chr,]

                        ADE=tempADEchr[tempADEchr[,8]>=0.8,]
                        countADE=length(unique(ADE[,3]))

                        countTOTAL=length(unique(tempTOTALchr[,3]))
                        ratio=countADE/countTOTAL

                        Cell=tempADE[1,1]

                        caca = cbind(as.character(Cell),as.numeric(ratio))

                        results=rbind(results,caca)

                        }

                }
}
write.table(results,file=paste(args[2],"/",chr,"_","ADE_ratio.txt",sep=""),quote=FALSE,col.names=FALSE,row.names=FALSE, sep="\t")


