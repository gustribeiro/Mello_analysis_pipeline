
args=commandArgs(TRUE)

listADE=list.files(pattern="_ADE_genes.txt",full.names=TRUE,path=args[1])
listTOTAL=list.files(patter="_TOTAL_genes.txt",full.names=TRUE,path=args[1])

s=1
while (s<23){
results=cbind("Cell","Ratio")
chr=paste("chr",s,sep="")

for (i in listADE){
        cond1=gsub(gsub(i,pattern="_ADE_genes.txt", replacement=""),pattern=".*/",replacement="")
   for (k in listTOTAL){
                cond2=gsub(gsub(k,pattern="_TOTAL_genes.txt", replacement=""),pattern=".*/",replacement="")
       
		if(cond1 == cond2){
		        tempADE<-read.table(i, header=FALSE)
			tempTOTAL<-read.table(k, header=FALSE)
			print(i)
			print(k)

			tempADEchr=tempADE[tempADE[,2]==chr,]
			tempTOTALchr=tempTOTAL[tempTOTAL[,2]==chr,]

			ADE=tempADEchr[tempADEchr[,8]>=0.8,]
			countADE=length(unique(ADE[,3]))

			countTOTAL=length(unique(tempTOTALchr[,3]))
			ratio=countADE/countTOTAL

			Cell=tempADE[1,1]

			temp = cbind(as.character(Cell),as.numeric(ratio))

			results=rbind(results,temp)

			}

		}


}
write.table(results,file=paste(args[2],"/",chr,"_","ADE_ratio.txt",sep=""),quote=FALSE,col.names=FALSE,row.names=FALSE, sep="\t")
print(chr)
s=s+1
}

#### repeat for X chromossome

chr="chrX"
results=cbind("Cell","Ratio")
print(chr)

for (i in listADE){
        cond1=gsub(gsub(i,pattern="_ADE_genes.txt", replacement=""),pattern=".*/",replacement="")
   for (k in listTOTAL){
                cond2=gsub(gsub(k,pattern="_TOTAL_genes.txt", replacement=""),pattern=".*/",replacement="")

                if(cond1 == cond2){
                        tempADE<-read.table(i, header=FALSE)
                        tempTOTAL<-read.table(k, header=FALSE)
                        print(i)
                        print(k)

                        tempADEchr=tempADE[tempADE[,2]==chr,]
                        tempTOTALchr=tempTOTAL[tempTOTAL[,2]==chr,]

                        ADE=tempADEchr[tempADEchr[,8]>=0.8,]
                        countADE=length(unique(ADE[,3]))

                        countTOTAL=length(unique(tempTOTALchr[,3]))
                        ratio=countADE/countTOTAL

                        Cell=tempADE[1,1]

                        temp = cbind(as.character(Cell),as.numeric(ratio))

                        results=rbind(results,temp)

                        }

                }
}
write.table(results,file=paste(args[2],"/",chr,"_","ADE_ratio.txt",sep=""),quote=FALSE,col.names=FALSE,row.names=FALSE, sep="\t")


