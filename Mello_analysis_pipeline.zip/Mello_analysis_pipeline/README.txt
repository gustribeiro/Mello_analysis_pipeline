Moreira de Mello et. al., 2017


To run the analysis performed in the paper, you need to have the following input files:

	-VCF file of each sample: annotated VCF with 39 eighth collumns;
		  columns  1 to 10: Standard VCF formart;
		  columns 11 to 20: Fields from annotation procedure (CHROM, POS, rsID, CHROM, GENE Symbol, gene TYPE, START pos, END pos, if Imprinted, inside XIC);
		  columns 21 to 34: Splitted column 10th (Sample-level annotations, default with VarScan software);
		  column  35: 	    Sum of reads in the reference (25th column) and alternative (26th column) alleles position;
		  column  36: 	    Relative expression frequency of reference allele, calculated as 25th/35th;
		  column  37:       Relative expression frequency of alternative allele, calculated as 26th/35th;
		  column  38:       TH stands for tophat, the aligner used in this work;
		  column  39:       Adjusted frequency of the reference allele. If < 0.5 use 1 - 36th column value, else use 36th column value;
		  all fields using a tab separator.

	-Embryo_list.txt file (tab-delimited file with Embryo name an Cell/Sample name, the sample name have to be the first field in the file name and separated by an _ character from any other annotation in the file name)	
	-List of SNPs in the pseudo-autosomal region (chrX_PAR1e2_meudb file in the supplied example)
	-List of biallelic SNPs in an male control (hESp0_BIAL_SNPs_and_freqAjust file in the supplied example)


VCF file example:
#CHROM	POS	ID	REF	ALT	QUAL	FILTER	INFO	FORMAT	Sample1	CHROM	POS	rsID	CHROM	GENE	TYPE	START	END	Imprinting	XIC	GT	GQ	SDP	DP	RD	AD	FREQ	PVAL	RBQ	ABQ	RDF	RDR	ADF	ADR	SumofRedas	RefFreq	AltFreq	Aligner	FreqAdjust
chr1	566130	.	C	T	.	PASS	ADP=23;WT=0;HET=0;HOM=1;NC=0	GT:GQ:SDP:DP:RD:AD:FREQ:PVAL:RBQ:ABQ:RDF:RDR:ADF:ADR	1/1:129:23:23:0:23:100%:1.2146E-13:0:39:0:0:10:13	chr1	566130	rs1832730	chr1	RP5-857K21.4	lincRNA	536816	659930	NONE	NONE	1/1	129	23	23	0	23	100%	1.2146E-13	0	39	0	0	10	13	23	0	1	TH	1


Male biallelic and PAR SNPs:
	This two files are in the "controls" folder.

VCF file and Embryo_list.txt:
	An set of a four-cell embryo vcf files and Embryo_list.txt are provided as example in the "input" folder.

All scripts used to perform the individual steps of the analysis are located in the "scripts" folder.


RUNNING THE ANALYSIS:

bash Run_analysis.sh | bash
Hit enter and wait!

All files created during the process will be saved in the "results" folder, if desired replace the files in the input folder for your own files to analyse your personal data.

