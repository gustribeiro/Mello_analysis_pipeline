Mello Et. al., 2017


To run the analysis performed in the paper, you need to have the following input files:

	-VCF file of each sample (standard VCF formart where the INFO collumn, eighth collumn, is repeated using a tab separator instead of a semicolon)
	-Embryo_list.txt file (tab-delimited file with Embryo name an Cell/Sample name, the sample name have to be the the first field in the file name and separated by an _ character from any other annotation in the file name)	
	-List of SNPs in the pseudo-autosomal region (chrX_PAR1e2_meudb file in the supplied example)
	-List of biallelic SNPs in an male control (hESp0_BIAL_SNPs_and_freqAjust file in the supplied example)


VCF file example:
chr1    566130  .       C       T       .       PASS    ADP=25;WT=0;HET=0;HOM=1;NC=0    GT:GQ:SDP:DP:RD:AD:FREQ:PVAL:RBQ:ABQ:RDF:RDR:ADF:ADR    1/1:141:25:25:0:25:100%:7.9107E-15:0:37:0:0:11:14
       chr1    566130  rs1832730       chr1    RP5-857K21.4    lincRNA 536816  659930  NONE    NONE    1/1     141     25      25      0       25      100%    7.9107E-15      0       37      0
       0       11      14              25      01      TH      1

Male biallelic and PAR SNPs:
	This two files are in the "controls" folder.

VCF file and Embryo_list.txt:
	An set of a four-cell embryo vcf files and Embryo_list.txt are provided as example in the "input" folder.

All scripts used to perform the individual steps of the analysis are located in the "scripts" folder.


RUNNING THE ANALYSIS:

From the folder where this README file is located, type "pwd" on the command line, hit enter, copy the output of the paste in the Run_analysis.sh between the double quotes
in the third line of the script. 
	Ex.: path="..paste pwd output here.."; 

Once altered save and exit the files.
To run the analysis type: bash Run_analysis.sh | bash
Hit enter and wait.

All files created during the process will be saved in the "results" folder, if desired replace the files in the input folder for your own files to analyse your personal data.

