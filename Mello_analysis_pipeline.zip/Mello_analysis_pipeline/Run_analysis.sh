#!/bin/bash

## Input folder path
path="/Users/gustavo/Desktop/Dropbox/lab/Outros/Joana/automacao/ADEvsBIAL_MegaPipe";  					



####################################################################################################################
####################################################################################################################
### Building folders path


path_input="$path/input";
path_output="$path/results";
path_male_control="$path/controls/hESp0_BIAL_SNPs_and_freqAjust";
path_PAR="$path/controls/chrX_PAR1e2_meudb";
path_embryo_list="$path_input/Embryo_list.txt"; 
path_scripts="$path/scripts"; 

##################################################################################################################

################ first step: add the cell name in the first collumn of each file;

mkdir -p $path_output/01_renamed

for Files in `ls "$path_input" | grep -v Embryo_list.txt`;
do 
	sample_name=`echo $Files | perl -ple 's/_.*//g'`;
	echo "perl -ple 's/^/"$sample_name"\t/gi' "$path_input"/"$Files" > "$path_output"/01_renamed/"$sample_name".txt";
	
done;

################ second and third step: remove biallelic snps found in the X chromossome of the hESp0 cell, and any PAR snp.

mkdir -p $path_output/02_03_remove_hES_BIAL_PAR

echo "Rscript "$path_scripts"/Removing_MaleX-bial_PAR.R "$path_male_control" "$path_PAR" "$path_output"/01_renamed "

############# fourth step: concatenate cells from the same embryo

mkdir -p $path_output/04_catCells

echo "Rscript "$path_scripts"/script_cat.R  "$path_embryo_list" "$path_output"/02_03_remove_hES_BIAL_PAR "$path_output"/04_catCells"

############### fifth step: idenfity snps present in more than one cell of the same embryo

mkdir -p $path_output/05_commom_SNPs

echo "Rscript "$path_scripts"/script_commom_SNPs.R  "$path_output"/04_catCells 5"
wait

############### sixth step: Select SNPS


mkdir -p $path_output/06_VarDiff_and_0or1


for Files in `awk '{print $1}' $path_embryo_list| sort| uniq | grep -v "Embryo_name"`
do
	echo "perl "$path_scripts"/sel_var_w_diff_freq_0or1.pl -v "$path_output"/05_commom_SNPs/"$Files".txt -o "$path_output"/06_VarDiff_and_0or1/"$Files"_Diff0or1.txt";
	echo "perl "$path_scripts"/sel_var_w_diff_freq_corrigido.pl -v "$path_output"/05_commom_SNPs/"$Files".txt -o "$path_output"/06_VarDiff_and_0or1/"$Files"_VarDiff.txt";

done;

############ Seventh step: remove inconsistent snps

mkdir -p $path_output/07_GenesInconsistentes

for Files in `awk '{print $1}' $path_embryo_list| sort| uniq | grep -v "Embryo_name"`
do
        echo "perl "$path_scripts"/Automatic_inconsistent_filter.pl -v "$path_output"/06_VarDiff_and_0or1/"$Files"_VarDiff.txt -d "$path_output"/06_VarDiff_and_0or1/"$Files"_Diff0or1.txt -o "$path_output"/07_GenesInconsistentes/"$Files"_noINC.txt -a "$path_output"/05_commom_SNPs/"$Files".txt -f "$path_output"/07_GenesInconsistentes/"$Files"_INC.txt"

done;

############ eighth step: idenfity snps present in more than one cell of the same embryo

mkdir -p $path_output/08_commomSNPs_noINC

echo "Rscript "$path_scripts"/script_commom_SNPs.R  "$path_output"/07_GenesInconsistentes 8"

############### ninth step: Select SNPS per embryo


mkdir -p $path_output/09_VarDiff_and_0or1_noInc

for Files in `awk '{print $1}' $path_embryo_list| sort| uniq | grep -v "Embryo_name"`
do

        echo "perl "$path_scripts"/sel_var_w_diff_freq_0or1.pl -v "$path_output"/08_commomSNPs_noINC/"$Files"_noINC.txt -o "$path_output"/09_VarDiff_and_0or1_noInc/"$Files"_Diff0or1.txt "
        echo "perl "$path_scripts"/sel_var_w_diff_freq_corrigido.pl -v "$path_output"/08_commomSNPs_noINC/"$Files"_noINC.txt -o "$path_output"/09_VarDiff_and_0or1_noInc/"$Files"_VarDiff.txt "

done;

############### tenth step: separate embryo cells and ADE/BIAL genes for each cell

mkdir -p $path_output/10_filtered_files

for Files in `awk '{print $1}' $path_embryo_list| sort| uniq | grep -v "Embryo_name"`
do
	echo "awk  -v var="$path_output"/10_filtered_files '{print \$1\"\t\"\$2\"\t\"\$16\"\t\"$14\"\t\"\$37\"\t\"\$38\"\t\"\$39\"\t\"\$40 > (var\"/\"\$1\"_all_genes.txt\")}' "$path_output"/08_commomSNPs_noINC/"$Files"_noINC.txt";

        echo "awk  -v var="$path_output"/10_filtered_files '{print \$1\"\t\"\$2\"\t\"\$16\"\t\"$14\"\t\"\$37\"\t\"\$38\"\t\"\$39\"\t\"\$40 > (var\"/\"\$1\"_ADE_genes.txt\")}' "$path_output"/09_VarDiff_and_0or1_noInc/"$Files"_Diff0or1.txt";

        echo "awk  -v var="$path_output"/10_filtered_files '{print \$1\"\t\"\$2\"\t\"\$16\"\t\"$14\"\t\"\$37\"\t\"\$38\"\t\"\$39\"\t\"\$40 > (var\"/\"\$1\"_BIAL_genes.txt\")}' "$path_output"/09_VarDiff_and_0or1_noInc/"$Files"_VarDiff.txt";
done
############### eleventh step: Calculate the ratio of BIAL and ADE genes for each cell

mkdir -p $path_output/11_countingADEvsBIAL

echo "Rscript "$path_scripts"/script_BIAL_ratio.R  "$path_output"/10_filtered_files $path_output/11_countingADEvsBIAL"
echo "Rscript "$path_scripts"/script_ADE_ratio.R  "$path_output"/10_filtered_files $path_output/11_countingADEvsBIAL"

exit;
